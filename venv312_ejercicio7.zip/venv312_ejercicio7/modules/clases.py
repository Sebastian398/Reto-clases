#*****
#Centro de Biotecnologia Agropecuaria
#Ficha:2877795
#aprendiz: Neider Sebastian Ramirez Delgadillo
#Version:3.12
#Fecha:06/05/2024
#*****

#Se importan las librerias
from random import randint
from datetime import datetime,timedelta

'''
Este programa crea distintas clases que almacenan datos y permiten que las subclases hereden datos de las super clases
'''

#Se crea la clase Persona
class Persona:

    #Se establecen los atributos
    def __init__(self, id_persona='0', name='', apellido='',fecha_nacimiento='',ciudad_nacimiento='',genero='',estrato=0):
      
        self.__id_persona = id_persona
        self.__name = name
        self.__apellido = apellido
        self.__fecha_nacimiento = fecha_nacimiento
        self.__ciudad_nacimiento = ciudad_nacimiento
        self.__genero = genero
        self.__estrato = estrato

    #Se usan los metodos getter y setter para generar y retornar los datos
    def set_id_persona(self,value):
        self.__id_persona = value
    
    def get_id_persona(self):
        return self.__id_persona
    
    def set_name(self,value):
        self.__name = value

    def get_name(self):
        return self.__name
    
    def set_apellido(self,value):
        self.__apellido = value

    def get_apellido(self):
        return self.__apellido
    
    def set_fecha_nacimiento(self,value):
        self.__fecha_nacimiento = value

    def get_fecha_nacimiento(self):
        return self.__fecha_nacimiento
    
    def set_ciudad_nacimiento(self,value):
        self.__ciudad_nacimiento = value

    def get_ciudad_nacimiento(self):
        return self.__ciudad_nacimiento
    
    def set_genero(self,value):
        self.__genero = value

    def get_genero(self):
        return self.__genero
    
    def set_estrato(self,value):
        self.__estrato = value

    def get_estrato(self):
        return self.__estrato
    
    #La funcion mostrar_dg imprime el mensaje "El Dg es Holaaaa :)"
    def mostrar_dg(self):
        print("El Dg es Holaaaa :)")

    #La funcion Calcula_EPS elige en que EPS se encuentra vinculado el usuario
    def calcula_EPS(self):
        EPS = ["Compensar", "Sanitas", "Sisben", "Colsubsidio"]
        alt = randint(0, len(EPS)-1)
        print("Su EPS es:")
        print(EPS[alt])

    #La funcion Calcula_pension muestra el valor de la pension mensualmente
    def Calcula_pension(self):
        print("Su pension es a valor de 1500000 mensual")
    
    #La funcion Calcula_ARL elige en que ARL se encuentra vinculado el usuario
    def Calcula_ARL(self):
        ARL = ["Activo", "Inactivo"]
        alt = randint(0, len(ARL)-1)
        print("Su ARL es:")
        print(ARL[alt])
    
    #La funcion Calcula_SENA elige en que estado se encuentra el usuario
    def Calcula_SENA(self):
        SENA = ["Inscrito", "Matriculado", "Suspendido"]
        alt = randint(0, len(SENA)-1)
        print("Su estado en el SENA es:")
        print(SENA[alt])
    
    #La funcion Calcula_cajas elige en que caja social se encuentra vinculado el usuario
    def Calcula_cajas(self):
        Cajas = ["Caja social", "Bancolombia", "Davivienda", "BBVA"]
        alt = randint(0, len(Cajas)-1)
        print("Su caja de compensacion es:")
        print(Cajas[alt])
    
    #La funcion Calcula_ICBF elige en que estado se encuentra el usuario
    def Calcula_ICBF(self):
        ICBF = ["Miembro activo", "Miembro egresado", "No aplica"]
        alt = randint(0,len(ICBF)-1)
        print("Su estado en el ICBF es:")
        print(ICBF[alt])
    
    #La funcion Calcula_auxilio elige en que EPS se encuentra vinculado el usuario
    def Calcula_auxilio(self):
        Auxilio = ["Recibe un auxilio", "No recibe auxilio"]
        alt = randint(0, len(Auxilio)-1)
        print("Su estado respecto a los auxilios es:")
        print(Auxilio[alt])

#Se crea la clase Docentes
class Docentes(Persona):

    #Se establecen los atributos
    def __init__(self, area_formacion='', titulo_profesional='', unidad_academica='', id_persona=0, name='', apellido='', fecha_nacimiento='', ciudad_nacimiento='', genero='', estrato=0 ):
        
        #Se heredan los atributos de la super clase
        super().__init__(id_persona, name, apellido, fecha_nacimiento, ciudad_nacimiento, genero, estrato )

        self.__area_formacion = area_formacion
        self.__titulo_profesional = titulo_profesional
        self.__unidad_academica = unidad_academica

    #Se usan los metodos getter y setter para generar y retornar los datos
    def set_area_formacion(self,value):
        self.__area_formacion = value
    
    def get_area_formacion(self):
        return self.__area_formacion
    
    def set_titulo_profesional(self,value):
        self.__titulo_profesional = value

    def get_titulo_ptofesional(self):
        return self.__titulo_profesional
    
    def set_unidad_academica(self,value):
        self.__unidad_academica = value

    def get_unidad_academica(self):
        return self.__unidad_academica
    
    #La funcion Mostrar_datos muestra la informacion que recien digito el usuario
    def Mostrar_datos(self):
        print(f' El area de formacion es {0}, su titulo profesional es {1} y la unidad academica es la {2}'.format(self.get_area_formacion(), 
                                                                                                                   self.get_titulo_ptofesional(), 
                                                                                                                   self.get_unidad_academica()))
    
#Se crea la clase Tiempo_completo
class Tiempo_completo(Docentes):

    #Se establecen los atributos
    def __init__(self, categorias='', puntos=0, salario=0, area_formacion='', titulo_profesional='', unidad_academica='', id_persona=0, name='', apellido='', fecha_nacimiento='', ciudad_nacimiento='', genero='', estrato=0):
        
        #Se heredan los atributos de la super clase
        super().__init__(area_formacion, titulo_profesional, unidad_academica, id_persona, name, apellido, fecha_nacimiento, ciudad_nacimiento, genero, estrato)
        
        self.__categorias = categorias
        self.__puntos = puntos
        self.__salaio = salario

    #Se usan los metodos getter y setter para generar y retornar los datos
    def set_categorias(self,value):
        self.__categorias = value
    
    def get_categorias(self):
        return self.__categorias
    
    def set_puntos(self,value):
        self.__puntos = value

    def get_puntos(self):
        return self.__puntos
    
    def set_salario(self,value):
        self.__salario = value
     
    def get_salario(self):
        return 1500000
    
    #Se calcula el sueldo anual del usuario
    def calcula_sueldo(self):
        return 1500000 * 12
    
    #Muestra el valor de la liquidacion del usuario
    def liquidar_tc(self):
        return 3000000
    
    #Determina en cuanto tiempo sera entregada su liquidacion
    def mostrar_liquidacion(self):
        tc = ["2 semanas", "3 semanas"]
        alt = randint(0, len(tc)-1)
        return tc[alt]    

#Se crea la clase Ocasionales
class Ocasionales(Docentes):

    #Se establecen los atributos
    def __init__(self, ultimo_titulo='', numero_meses=0, salario=0, area_formacion='', titulo_profesional='', unidad_academica='', id_persona=0, name='', apellido='', fecha_nacimiento='', ciudad_nacimiento='', genero='', estrato=0):
        
        #Se heredan los atributos de la super clase
        super().__init__(area_formacion, titulo_profesional, unidad_academica, id_persona, name, apellido, fecha_nacimiento, ciudad_nacimiento, genero, estrato)
        
        self.__ultimo_titulo = ultimo_titulo
        self.__numero_meses = numero_meses
        self.__salario = salario

    #Se usan los metodos getter y setter para generar y retornar los datos
    def set_ultimo_titulo(self,value):
        self.__ultimo_titulo = value
    
    def get_ultimo_titulo(self):
        return self.__ultimo_titulo
    
    def set_numero_meses(self,value):
        self.__numero_meses = value

    def get_numero_meses(self):
        return self.__numero_meses
    
    def set_salario(self,value):
        self.__salario = value
     
    def get_salario(self):
        return 1500000
    
    #Se calcula el sueldo anual del usuario
    def calcula_sueldo(self):
        return 1500000 * 12
    
    #Muestra el valor de la liquidacion del usuario
    def liquidar_oc(self):
        return 3000000
    
    #Determina en cuanto tiempo sera entregada la liquidacion del usuario
    def mostrar_liquidacion(self):
        oc = ["2 semanas", "3 semanas"]
        alt = randint(0, len(oc)-1)
        return oc[alt]

#Se crea la clase Hora_catedra    
class Hora_catedra(Docentes):

    #Se establecen los atributos
    def __init__(self, ultimo_titulo='', numero_horas=0, valor_contrato=0, salario=0, area_formacion='', titulo_profesional='', unidad_academica='', id_persona=0, name='', apellido='', fecha_nacimiento='', ciudad_nacimiento='', genero='', estrato=0):
        
        #Se heredan los atributos de la super clase
        super().__init__(area_formacion, titulo_profesional, unidad_academica, id_persona, name, apellido, fecha_nacimiento, ciudad_nacimiento, genero, estrato)
        
        self.__ultimo_titulo = ultimo_titulo
        self.__numero_horas = numero_horas
        self.__valor_contrato = valor_contrato
        self.__salario = salario

    #Se usan los metodos getter y setter para generar y retornar los datos
    def set_ultimo_titulo(self,value):
        self.__ultimo_titulo = value
    
    def get_ultimo_titulo(self):
        return self.__ultimo_titulo
    
    def set_numero_horas(self,value):
        self.__numero_horas = value

    def get_numero_horas(self):
        return self.__numero_horas
    
    def set_valor_contrato(self,value):
        self.__valor_contrato = value

    def get_valor_contrato(self):
        return self.__valor_contrato
    
    def set_salario(self,value):
        self.__salario = value
     
    def get_salario(self):
        return 1500000
    
    #Se calcula el sueldo anual del usuario
    def calcula_sueldo(self):
        return 1500000 * 12
    
    #Muestra el valor de la liquidacion del usuario
    def liquidar_hc(self):
        return 3000000
    
    #Determina en cuanto tiempo sera entregada la liquidacion del usuario
    def mostrar_liquidacion(self):
        hc = ["2 semanas", "3 semanas"]
        alt = randint(0, len(hc)-1)
        return hc[alt]
        
#Se crea la clase Administrativos    
class Administrativos(Persona):

    #Se establecen los atributos
    def __init__(self, dependencia='', titulo='', id_persona=0, name='', apellido='', fecha_nacimiento='', ciudad_nacimiento='', genero='', estrato=0 ):
        
        #Se heredan los atributos de la super clase
        super().__init__(id_persona, name, apellido, fecha_nacimiento, ciudad_nacimiento, genero, estrato )

        self.__dependencia = dependencia
        self.__titulo = titulo

    #Se usan los metodos getter y setter para generar y retornar los datos
    def set_dependencia(self, value):
        self.__dependencia = value

    def get_dependencia(self):
        return self.__dependencia

    def set_titulo(self, value):
        self.__titulo = value

    def get_titulo(self):
        return self.__titulo

    #La funcion mostrar_datos muestra los datos almacenados en los atributos
    def mostrar_datos(self):
        print('La dependencia es {0} y el titulo es {1}'.format(self.get_dependencia(), self.get_titulo()))

#Se crea la clase Planta       
class Planta(Administrativos):

    #Se establecen los atributos
    def _init_(self, fecha_vinculacion='', dependencia='', titulo='', id_persona=0, name='', apellido='', fecha_nacimiento='', ciudad_nacimiento='', genero='', estrato=0 ):
        
        #Se heredan los atributos de la super clase
        super().__init__(dependencia, titulo, id_persona, name, apellido, fecha_nacimiento, ciudad_nacimiento, genero, estrato)
        
        self.__fecha_vinculacion = datetime.strptime(fecha_vinculacion, '%Y-%m-%d')

    #Se usan los metodos getter y setter para generar y retornar los datos
    #La funcion set_fecha_vinculacion usa el formato de la libreria datetime para establecer la fecha   
    def set_fecha_vinculacion(self, value):
        self.__fecha_vinculacion = datetime.strptime(value, '%d-%m-%Y')

    def get_fecha_vinculacion(self):
        return self.__fecha_vinculacion
    
    #La funcion informacion muestra los datos almacenados en los atributos
    def informacion(self):
        print('La fecha de vinculacion es {0}'.format(self.get_fecha_vinculacion().strftime('%d-%m-%Y')))

#Se crea la clase OPS
class OPS(Administrativos):

    #Se establecen los atributos
    def _init_(self, fecha_vinculacion='', numero_meses=0, valor_contrato=0, salario=0, dependencia='', titulo='', id_persona=0, name='', apellido='', fecha_nacimiento='', ciudad_nacimiento='', genero='', estrato=0):
        
        #Se heredan los atributos de la super clase
        super().__init__(dependencia, titulo, id_persona, name, apellido, fecha_nacimiento, ciudad_nacimiento, genero, estrato)
        
        self.__fecha_vinculacion = datetime.strptime(fecha_vinculacion,'%Y-%m-%d')
        self.__numero_meses = numero_meses
        self.__valor_contrato = valor_contrato
        self.__salario = salario

    #Se usan los metodos getter y setter para generar y retornar los datos
    def set_fecha_vinculacion(self,value):
        self.__fecha_vinculacion = datetime.strptime(value,'%d-%m-%Y')
    
    def get_fecha_vinculacion(self):
        return self.__fecha_vinculacion
    
    def set_numero_meses(self,value):
        self.__numero_meses = value

    def get_numero_meses(self):
        return self.__numero_meses
    
    def set_valor_contrato(self,value):
        self.__valor_contrato = value

    def get_valor_contrato(self):
        return self.__valor_contrato

    def set_salario(self,value):
        self.__salario = value
     
    def get_salario(self):
        return self.__salario
    
    #Muestra el valor de la liquidacion del usuario
    def liquidar_valor_contrato(self):
        return 3000000
    
    #Determina en cuanto tiempo el usuario recibira su liquidacion
    def mostrar_liquidacion_OPS(self):
        ops = ["2 semanas", "3 semanas"]
        alt = randint(0, len(ops)-1)
        return ops[alt]
    
#Se crea la clase Auxiliar
class Auxiliar(Planta):
    
    #Se establecen los atributos
    def _init_(self, nivel=0, salario=0, fecha_vinculacion='', dependencia='', titulo='', id_persona=0, name='', apellido='', fecha_nacimiento='', ciudad_nacimiento='', genero='', estrato=0):
        
        #Se heredan los atributos
        super().__init__(fecha_vinculacion, dependencia, titulo, id_persona, name, apellido, fecha_nacimiento, ciudad_nacimiento, genero, estrato)

        self.__nivel = nivel
        self.__salario = salario

    #Se usan los metodos getter y setter para el manejo de los datos que ingresa el usuario
    def set_nivel(self,value):
        self.__nivel = value

    def get_nivel(self):
        return self.__nivel
    
    def set_salario(self,value):
        self.__salario = value

    def get_salario(self):
        return 1500000
    
    #Se calcula cuantos salarios recibe el usuario de acuerdo al nivel que haya ingresado
    def calcular_sueldo(self):
        return 1500000 * self.get_nivel
    
    #Muestra la liquidacion del usuario
    def liquidacion_tec(self):
        return 3000000
    
    #Muestra todos los datos que alberga la clase
    def mostrar_liquidacion_tec(self):
        print('El nivel es {0}, el salario es {1}, su sueldo es{3} y su liquidacion es {4}'.format(self.get_nivel(), self.get_salario(), self.calcular_sueldo(), self.liquidacion_tec()))

#Se crea la clase Tecnico
class Tecnico(Planta):
    
    #Se establecen los atributos
    def _init_(self, nivel=0, salario=0, fecha_vinculacion='', dependencia='', titulo='', id_persona=0, name='', apellido='', fecha_nacimiento='', ciudad_nacimiento='', genero='', estrato=0 ):
        
        #Se heredan los atributos
        super().__init__(fecha_vinculacion, dependencia, titulo, id_persona, name, apellido, fecha_nacimiento, ciudad_nacimiento, genero, estrato )

        self.__nivel = nivel
        self.__salario = salario

    #Se usan los metodos getter y setter para el manejo de datos
    def set_nivel(self,value):
        self.__nivel = value

    def get_nivel(self):
        return self.__nivel
    
    def set_salario(self,value):
        self.__salario = value

    def get_salario(self):
        return 1500000
    
    #Se calcula cuantos salarios recibe el usuario de acuerdo al nivel que haya ingresado
    def calcular_sueldo(self):
        return 1500000 * self.get_nivel
    
    #Muestra el valor de la liquidacion del usuario
    def liquidacion_tec(self):
        return 3000000
    
    #Muestra todos los datos albergados en la clase
    def mostrar_liquidacion_tec(self):
        print('El nivel es {0}, el salario es {1}, su sueldo es{3} y su liquidacion es {4}'.format(self.get_nivel(), self.get_salario(), self.calcular_sueldo(), self.liquidacion_tec()))

#Se crea la clase Profesional
class Profesional(Planta):
    
    #Se establecen los atributos
    def _init_(self, nivel=0, salario=0, fecha_vinculacion='', dependencia='', titulo='', id_persona=0, name='', apellido='', fecha_nacimiento='', ciudad_nacimiento='', genero='', estrato=0 ):
        
        #Se heredan los atributos
        super().__init__(fecha_vinculacion, dependencia, titulo, id_persona, name, apellido, fecha_nacimiento, ciudad_nacimiento, genero, estrato )

        self.__nivel = nivel
        self.__salario = salario

    #Se usan los metodos getter y setter para el manejo de los datos
    def set_nivel(self,value):
        self.__nivel = value

    def get_nivel(self):
        return self.__nivel
    
    def set_salario(self,value):
        self.__salario = value

    def get_salario(self):
        return 1500000
    
    #Se calcula cuantos salarios recibe el usuario de acuerdo al nivel que haya ingresado
    def calcular_sueldo(self):
        return 1500000 * self.get_nivel
    
    #Muestra el valor de la liquidacion del usuario
    def liquidacion_tec(self):
        return 3000000
    
    #Muestra todos los datos que alberga la clase
    def mostrar_liquidacion_tec(self):
        print('El nivel es {0}, el salario es {1}, su sueldo es{3} y su liquidacion es {4}'.format(self.get_nivel(), self.get_salario(), self.calcular_sueldo(), self.liquidacion_tec()))
