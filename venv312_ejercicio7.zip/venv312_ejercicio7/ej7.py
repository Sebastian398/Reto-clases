#*****
#Centro de Biotecnologia Agropecuaria
#Ficha:2877795
#aprendiz: Neider Sebastian Ramirez Delgadillo
#Version:3.12
#Fecha:06/05/2024
#*****

#Se importa la libreria
import modules.clases as clases
from colorama import Fore

'''
Este programa muestra una serie de clases con datos sobre distintos funcionarios y como esas clases heredan datos de las superclases
'''

def main():   

    #Se instancia la clase
    persona1 = clases.Tiempo_completo() 

    #Se solicitan los datos al usuario
    persona1.set_id_persona (int(input(Fore.BLUE+"id de la persona: ")))

    persona1.set_name(input("nombre de la persona: "))
    
    persona1.set_apellido(input("apellido de la persona: "))
    
    persona1.set_fecha_nacimiento(input("fecha de nacimiento de la persona: "))
    
    persona1.set_ciudad_nacimiento(input("ciudad de nacimiento de la persona: "))
    
    persona1.set_genero(input("genero de la persona: "))
    
    persona1.set_estrato(input("estrato de la persona: "))

    #Muestran datos que genera el sistema    
    persona1.mostrar_dg()
    
    persona1.calcula_EPS()
    
    persona1.Calcula_pension()
    
    persona1.Calcula_ARL()
    
    persona1.Calcula_SENA()
    
    persona1.Calcula_cajas()
    
    persona1.Calcula_ICBF()
    
    persona1.Calcula_auxilio()

    #Se solicitan los datos al usuario
    persona1.set_area_formacion (input("area de formacion de la persona: "))

    persona1.set_titulo_profesional(input("titulo profesional de la persona: "))
    
    persona1.set_unidad_academica(input("unidad academica de la persona: "))

    #Se solicitan los datos al usuario
    persona1.set_categorias (input("categoria de la persona: "))

    persona1.set_puntos(int(input("puntos de la persona: ")))

    #Muestran datos que genera el sistema    
    persona1.get_salario()

    persona1.calcula_sueldo()
    
    persona1.liquidar_tc()
    
    persona1.mostrar_liquidacion()


    #Se instancia la clase
    persona2 = clases.Ocasionales()

    #Se solicitan los datos al usuario
    persona2.set_id_persona (int(input(Fore.GREEN+"id de la persona: ")))

    persona2.set_name(input("nombre de la persona: "))
    
    persona2.set_apellido(input("apellido de la persona: "))
    
    persona2.set_fecha_nacimiento(input("fecha de nacimiento de la persona: "))
    
    persona2.set_ciudad_nacimiento(input("ciudad de nacimiento de la persona: "))
    
    persona2.set_genero(input("genero de la persona: "))
    
    persona2.set_estrato(input("estrato de la persona: "))

    #Muestran datos que genera el sistema    
    persona2.mostrar_dg()
    
    persona2.calcula_EPS()
    
    persona2.Calcula_pension()
    
    persona2.Calcula_ARL()
    
    persona2.Calcula_SENA()
    
    persona2.Calcula_cajas()
    
    persona2.Calcula_ICBF()
    
    persona2.Calcula_auxilio()

    #Se solicitan los datos al usuario
    persona2.set_area_formacion (input("area de formacion de la persona: "))

    persona2.set_titulo_profesional(input("titulo profesional de la persona: "))
    
    persona2.set_unidad_academica(input("unidad academica de la persona: "))    

    #Se solicitan los datos al usuario
    persona2.set_ultimo_titulo (input("ultimo titulo de la persona: "))

    persona2.set_numero_meses(int(input("numero de meses de la persona: ")))
    
    #Muestran datos que genera el sistema    
    persona2.get_salario()
   
    persona2.calcula_sueldo()
    
    persona2.liquidar_oc()
    
    persona2.mostrar_liquidacion()

    #Se instancia la clase
    persona3 = clases.Hora_catedra()

    #Se solicitan los datos al usuario
    persona3.set_id_persona (int(input(Fore.LIGHTCYAN_EX+"id de la persona: ")))

    persona3.set_name(input("nombre de la persona: "))
    
    persona3.set_apellido(input("apellido de la persona: "))
    
    persona3.set_fecha_nacimiento(input("fecha de nacimiento de la persona: "))
    
    persona3.set_ciudad_nacimiento(input("ciudad de nacimiento de la persona: "))
    
    persona3.set_genero(input("genero de la persona: "))
    
    persona3.set_estrato(input("estrato de la persona: "))

    #Muestran datos que genera el sistema    
    persona3.mostrar_dg()
    
    persona3.calcula_EPS()
    
    persona3.Calcula_pension()
    
    persona3.Calcula_ARL()
    
    persona3.Calcula_SENA()
    
    persona3.Calcula_cajas()
    
    persona3.Calcula_ICBF()
    
    persona3.Calcula_auxilio()

    #Se solicitan los datos al usuario
    persona3.set_area_formacion (input("area de formacion de la persona: "))

    persona3.set_titulo_profesional(input("titulo profesional de la persona: "))
    
    persona3.set_unidad_academica(input("unidad academica de la persona: "))
    
    #Se solicitan los datos al usuario
    persona3.set_ultimo_titulo (input("ultimo titulo de la persona: "))

    persona3.set_numero_horas(int(input("numero de horas de la persona: ")))
    
    persona3.set_valor_contrato(int(input("valor del contrato de la persona: ")))

    #Muestran datos que genera el sistema    
    persona3.get_salario()
    
    persona3.calcula_sueldo()

    persona3.liquidar_hc()
    
    persona3.mostrar_liquidacion()

    #Se instancia la clase
    persona4 = clases.Auxiliar()

    #Se solicitan los datos al usuario
    persona4.set_id_persona (int(input(Fore.YELLOW+"id de la persona: ")))

    persona4.set_name(input("nombre de la persona: "))
    
    persona4.set_apellido(input("apellido de la persona: "))
    
    persona4.set_fecha_nacimiento(input("fecha de nacimiento de la persona: "))
    
    persona4.set_ciudad_nacimiento(input("ciudad de nacimiento de la persona: "))
    
    persona4.set_genero(input("genero de la persona: "))
    
    persona4.set_estrato(input("estrato de la persona: "))

    #Muestran datos que genera el sistema    
    persona4.mostrar_dg()
    
    persona4.calcula_EPS()
    
    persona4.Calcula_pension()
    
    persona4.Calcula_ARL()
    
    persona4.Calcula_SENA()
    
    persona4.Calcula_cajas()
    
    persona4.Calcula_ICBF()
    
    persona4.Calcula_auxilio()
    
    #Se solicitan los datos al usuario
    persona4.set_dependencia (input("dependencia de la persona: "))

    persona4.set_titulo(input("titulo de la persona: "))     

    #Se solicita el dato al usuario
    persona4.set_fecha_vinculacion(input("fecha de vinculacion de la persona: "))

     #Muestra el dato que ingresa el usuario 
    print(persona4.get_fecha_vinculacion())     

    #Se solicita el dato al usuario
    persona4.set_nivel (int(input("nivel de la persona: ")))

    #Muestra los datos que genera el sistema    
    persona4.get_salario()

    persona4.calcular_sueldo()            
    
    persona4.liquidacion_tec()

    persona4.mostrar_liquidacion_tec()

    #Se instancia la clase
    persona5 = clases.Tecnico()

    #Se solicitan los datos al usuario
    persona5.set_id_persona (int(input(Fore.RED+"id de la persona: ")))

    persona5.set_name(input("nombre de la persona: "))
    
    persona5.set_apellido(input("apellido de la persona: "))
    
    persona5.set_fecha_nacimiento(input("fecha de nacimiento de la persona: "))
    
    persona5.set_ciudad_nacimiento(input("ciudad de nacimiento de la persona: "))
    
    persona5.set_genero(input("genero de la persona: "))
    
    persona5.set_estrato(input("estrato de la persona: "))

    #Muestran datos que genera el sistema    
    persona5.mostrar_dg()
    
    persona5.calcula_EPS()
    
    persona5.Calcula_pension()
    
    persona5.Calcula_ARL()
    
    persona5.Calcula_SENA()
    
    persona5.Calcula_cajas()
    
    persona5.Calcula_ICBF()
    
    persona5.Calcula_auxilio()
    
    #Se solicitan los datos al usuario
    persona5.set_dependencia (input("dependencia de la persona: "))

    persona5.set_titulo(input("titulo de la persona: "))     

    #Se solicita el dato al usuario
    persona5.set_fecha_vinculacion(input("fecha de vinculacion de la persona: "))

     #Muestra el dato que ingresa el usuario 
    print(persona5.get_fecha_vinculacion())     

    #Se solicita el dato al usuario
    persona5.set_nivel (int(input("nivel de la persona: ")))
    
    #Se solicita el dato al usuario
    persona5.set_nivel (int(input("nivel de la persona: ")))

    #Muestra los datos que genera el sistema    
    persona5.get_salario()

    persona5.calcular_sueldo()            
    
    persona5.liquidacion_tec()

    persona5.mostrar_liquidacion_tec()

    #Se instancia la clase
    persona6 = clases.Profesional()    

    #Se solicitan los datos al usuario
    persona6.set_id_persona (int(input(Fore.LIGHTBLUE_EX+"id de la persona: ")))

    persona6.set_name(input("nombre de la persona: "))
    
    persona6.set_apellido(input("apellido de la persona: "))
    
    persona6.set_fecha_nacimiento(input("fecha de nacimiento de la persona: "))
    
    persona6.set_ciudad_nacimiento(input("ciudad de nacimiento de la persona: "))
    
    persona6.set_genero(input("genero de la persona: "))
    
    persona6.set_estrato(input("estrato de la persona: "))

    #Muestran datos que genera el sistema    
    persona6.mostrar_dg()
    
    persona6.calcula_EPS()
    
    persona6.Calcula_pension()
    
    persona6.Calcula_ARL()
    
    persona6.Calcula_SENA()
    
    persona6.Calcula_cajas()
    
    persona6.Calcula_ICBF()
    
    persona6.Calcula_auxilio()
    
    #Se solicitan los datos al usuario
    persona6.set_dependencia (input("dependencia de la persona: "))

    persona6.set_titulo(input("titulo de la persona: "))     

    #Se solicita el dato al usuario
    persona6.set_fecha_vinculacion(input("fecha de vinculacion de la persona: "))

     #Muestra el dato que ingresa el usuario 
    print(persona6.get_fecha_vinculacion())     

    #Se solicita el dato al usuario
    persona6.set_nivel (int(input("nivel de la persona: ")))

    #Se solicita el dato al usuario
    persona6.set_nivel (int(input("nivel de la persona: ")))

    #Muestra los datos que genera el sistema    
    persona6.get_salario()

    persona6.calcular_sueldo()            
    
    persona6.liquidacion_tec()

    persona6.mostrar_liquidacion_tec()

    #Se instancia la clase
    persona7 = clases.OPS()

    #Se solicitan los datos al usuario
    persona7.set_id_persona (int(input(Fore.LIGHTGREEN_EX+"id de la persona: ")))

    persona7.set_name(input("nombre de la persona: "))
    
    persona7.set_apellido(input("apellido de la persona: "))
    
    persona7.set_fecha_nacimiento(input("fecha de nacimiento de la persona: "))
    
    persona7.set_ciudad_nacimiento(input("ciudad de nacimiento de la persona: "))
    
    persona7.set_genero(input("genero de la persona: "))
    
    persona7.set_estrato(input("estrato de la persona: "))

    #Muestran datos que genera el sistema    
    persona7.mostrar_dg()
    
    persona7.calcula_EPS()
    
    persona7.Calcula_pension()
    
    persona7.Calcula_ARL()
    
    persona7.Calcula_SENA()
    
    persona7.Calcula_cajas()
    
    persona7.Calcula_ICBF()
    
    persona7.Calcula_auxilio()
    
    #Se solicitan los datos al usuario
    persona7.set_dependencia (input("dependencia de la persona: "))

    persona7.set_titulo(input("titulo de la persona: "))     

    #Se solicitan los datos al usuario
    persona7.set_fecha_vinculacion(input("fecha de vinculacion de la persona: "))

    persona7.set_numero_meses(int(input("numero de meses de la persona: ")))
    
    persona7.set_valor_contrato(int(input("valor del contrato de la persona: ")))

    #Muestran datos que genera el sistema        
    persona7.liquidar_valor_contrato()
    
    persona7.mostrar_liquidacion_OPS()

if __name__ == "__main__":
    
    #Se ejecuta el programa 
    main()